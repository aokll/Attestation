package PetRegistyPackage;

public enum ClassAnimal {
    Млекопитающие,
    Пресмыкающиеся,
    Земноводные,
    Птицы,
    Рыбы


}
