package PetRegistyPackage;

import java.util.HashMap;
import java.util.Map;

public class FullTable {
    Map<String,String> resMap;

    public FullTable() {
        resMap = new HashMap<>();
    }

    public Map<String, String> getResMap() {
        return resMap;
    }
}
